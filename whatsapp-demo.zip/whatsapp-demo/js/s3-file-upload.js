var bucketName = "eyezeverywhere";
var bucketRegion = "us-west-1";
var IdentityPoolId = "AKIAUDFXPA77OJDF5Q4F";

/* AWS.config.update({
    region: bucketRegion,
    credentials: new AWS.CognitoIdentityCredentials({
        IdentityPoolId: IdentityPoolId
    })
});

var s3 = new AWS.S3({
    apiVersion: '2006-03-01',
    params: { Bucket: bucketName }
}); */

var s3 = new AWS.S3({
    accessKeyId: "AKIAZPM2DFBY7BENGCGG",
    secretAccessKey: "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",
    region: 'ap-south-1'
});

$(document).on('change', ".messageFileInput", function () {
    let files = $('#messageFileInput')[0].files
    if (files) {

        for (let index = 0; index < files.length; index++) {
            var file = files[index];
            console.log("file ===== >>>>", file);
            var fileName = file.name;
            var filePath = 'my-first-bucket-path/' + fileName;
            var fileUrl = 'https://' + bucketRegion + '.amazonaws.com/my-first-bucket/' + filePath;


            var upload = new AWS.S3.ManagedUpload({
                service: s3,
                params: {
                    Body: file,
                    Bucket: "testing-ebiz",
                    Key: file.name,
                    ACL: 'public-read',
                },
            });

            upload.send(function (err, data) {
                if (err) {
                    console.log(err);
                    console.log("Error", err.code, err.message);
                } else {
                    console.log(data);
                }
            });




            /* s3.upload({
                Key: filePath,
                Body: file,
                ACL: 'public-read'
            }, function (err, data) {
                console.log("data =====>>", data);
                if (err) {
                    console.log(err);
                }

            }).on('httpUploadProgress', function (progress) {
                var uploaded = parseInt((progress.loaded * 100) / progress.total);
                $("progress").attr('value', uploaded);
            }); */
        }

        console.log(files.length);


        /* files.forEach(file => {
            var fileName = file.name;
            var filePath = 'my-first-bucket-path/' + fileName;
            var fileUrl = 'https://' + bucketRegion + '.amazonaws.com/my-first-bucket/' + filePath;

            s3.upload({
                Key: filePath,
                Body: file,
                ACL: 'public-read'
            }, function (err, data) {
                console.log("data =====>>", data);
                if (err) {
                    reject('error');
                }

            }).on('httpUploadProgress', function (progress) {
                var uploaded = parseInt((progress.loaded * 100) / progress.total);
                $("progress").attr('value', uploaded);
            });
        }); */
    }
});