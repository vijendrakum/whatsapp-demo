// const socketUrl = "http://192.100.100.31:5000";
// const phpServerUrl = "https://wokii.io/public/api/V1/";

const socketUrl = "https://chat.wokii.io:8001/";
const phpServerUrl = "https://wokii.io/backend/public/api/V1/";

let existLoginData = localStorage.getItem("loginUserData")
let loginUserData = {};

let CurrentFriendData = {};
let currenFriendId = "";

let CurrentRoomData = {};
let currentRoomId = "";
let replyMessageId = "";
let currentgroupMembers = [];

if (existLoginData) {
    loginUserData = JSON.parse(existLoginData)
}
function isEmpty(obj) {
    for (const prop in obj) {
        if (Object.hasOwn(obj, prop)) {
            return false;
        }
    }
    return true;
}
$(document).ready(function (e) {
    if (isEmpty(loginUserData)) {
        $('#LoginModal').modal({
            backdrop: 'static',
            keyboard: false
        });
        $('#LoginModal').modal('show')
    } else {
        $('#LoginUserImage').attr('src', loginUserData.profile_image)
        $('#LoginUserName').text(loginUserData.display_name)
        getChatlist(loginUserData.chat_user_id)
    }
});

function submitGetOtp() {
    var phone_number = $('#MobileNumber').val();
    if (!phone_number) {
        return;
    }

    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");
    var formdata = new FormData();
    formdata.append("country_code", "");
    formdata.append("phone_number", phone_number);

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };
    fetch(phpServerUrl + "user/get-otp", requestOptions)
        .then(result => result.text())
        .then((response) => {
            response = JSON.parse(response)
            if (response.status == true) {
                $("#getOtpForm").hide();
                $("#varifyOTPForm").show();
            }
        })
        .catch(error => console.log('error', error));
}

function submitVeryfyOtp() {

    var phone_number = $('#MobileNumber').val();
    if (!phone_number) {
        return;
    }

    var otp = $('#OTP').val();
    if (!otp) {
        return;
    }


    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");

    var formdata = new FormData();
    formdata.append("country_code", "");
    formdata.append("phone_number", phone_number);
    formdata.append("otp", otp);
    formdata.append("varify_type", "signup");
    formdata.append("signup_type", "default");
    formdata.append("device_token", "");
    formdata.append("device_type", "android");

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow'
    };


    fetch(phpServerUrl + "user/verify-otp", requestOptions)
        .then(result => result.text())
        .then((response) => {
            response = JSON.parse(response)
            if (response.status == true) {
                localStorage.setItem("AuthToken", response.data.token)
                localStorage.setItem("loginUserData", JSON.stringify(response.data.user))
                loginUserData = response.data.user;
                socket.emit("join", { id: loginUserData.chat_user_id });
                getChatlist(loginUserData.chat_user_id)
                $('#MobileNumber').val('')
                $('#OTP').val('')
                $('#LoginModal').modal('hide')
                $('#LoginUserName').text(loginUserData.display_name)
                $('#LoginUserImage').attr('src', loginUserData.profile_image)
            }
        })
        .catch(error => console.log('error', error));


}

function getFriends() {
    let AuthToken = localStorage.getItem("AuthToken")

    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");
    myHeaders.append("Authorization", "Bearer " + AuthToken);

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(phpServerUrl + "user/followers/chat-users?search_srting=&page=", requestOptions)
        .then(result => result.text())
        .then((response) => {
            response = JSON.parse(response)
            if (response.status == true) {
                $('#FriendsListSection').empty();
                let friends = response.data;
                friends.forEach(element => {
                    const html = `
                    <div class="chat my-friends" onclick="createFriendChatRoom('`+ element._id + `','` + element.name + `','` + element.image + `')" id="Friend` + element._id + `">
                        <div class="chat-left">
                            <img src="`+ element.image + `" />
                        </div>
                        <div class="chat-right">
                            <div class="chat-right-top">
                                <span class="contact-name friend-name" friend-id="`+ element._id + `">` + element.name + `</span>
                            </div>
                        </div>
                    </div>`;
                    $('#FriendsListSection').append(html)
                });
                $('#FriendsModal').modal('show')
            }

        })
        .catch(error => console.log('error', error));

}

$(document).on('keyup', '#friendsSearchInput', function (e) {
    var searctext = $(this).val();
    if (searctext) {
        $('.my-friends').hide();
        $('.friend-name').each(function () {
            if ($(this).text().toUpperCase().indexOf(searctext.toUpperCase()) != -1) {
                $('#Friend' + $(this).attr('friend-id')).show()
            }
        })
    } else {
        $('.my-friends').show();
    }
});


function createFriendChatRoom(friendId, friendIdName, friendImage) {
    $('#myModal').modal('hide');
    CurrentFriendData = {
        _id: friendId,
        name: friendIdName,
        image: friendImage
    }
    currenFriendId = friendId;
    CurrentRoomData = {};
    currentRoomId = "";

    socket.emit("findRoom", { roomOwnerId: loginUserData.chat_user_id, roomMembers: [friendId], roomType: 'single' });


    $('#mainChatSection').show();
    $('#FriendsModal').modal('hide')
    $('#currentRoomMessagesection').empty();
    $('.type-message-bar').show();
    displayCurrentRoomInfo(CurrentFriendData);
}

function displayCurrentRoomInfo(data) {
    $('#currentRoomUserImage').attr('src', data.image)
    $('#currentRoomUserName').text(data.name)
}

function getMessageHistory(roomId, roomdName, roomImage, roomType, isUserExitedFromGroup) {
    setRoomUserPermissions(isUserExitedFromGroup);
    CurrentRoomData = {
        _id: roomId,
        name: roomdName,
        image: roomImage,
        roomType: roomType,
        isUserExitedFromGroup: isUserExitedFromGroup
    };
    currentRoomId = roomId;
    $("#unreadMessages" + currentRoomId).text(0)
    $("#unreadMessages" + currentRoomId).hide();
    $('#mainChatSection').show();
    $('#currentRoomMessagesection').empty();

    if (isUserExitedFromGroup == false) {
        socket.emit("joinRoom", { roomId: currentRoomId, userId: loginUserData.chat_user_id });
    }

    socket.emit("getChatHistory", { roomId: currentRoomId, userId: loginUserData.chat_user_id })
    displayCurrentRoomInfo(CurrentRoomData);
}

function showCreateGroupModal() {

    let AuthToken = localStorage.getItem("AuthToken")

    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");
    myHeaders.append("Authorization", "Bearer " + AuthToken);

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(phpServerUrl + "user/followers/chat-users?search_srting=&page=", requestOptions)
        .then(result => result.text())
        .then((response) => {
            response = JSON.parse(response)
            if (response.status == true) {
                $('#CreareGroupListSection').empty();
                let friends = response.data;
                friends.forEach(element => {
                    const html = `
                    <div class="chat create-group-friends" id="createGroupFriend`+ element._id + `">
                        <div class="chat-left">
                            <img src="`+ element.image + `" />
                        </div>
                        <div class="chat-right">
                            <div class="chat-right-top">
                                <span class="contact-name create-group-friend-name" friend-id="`+ element._id + `">` + element.name + `</span>
                            </div>
                            <div class="chat-right-bottom">
                                <div class="chat-right-bottom-left">
    
                                </div>
                                <div class="chat-right-bottom-right">
                                    <input type="checkbox" class="GroupFirend" value="`+ element._id + `" />
                                </div>
                            </div>
                        </div>
                    </div>`;
                    $('#CreareGroupListSection').append(html)
                });
                $('#CreareGroupModal').modal('show')
            }
        })
        .catch(error => console.log('error', error));
}



$(document).on('keyup', '#creareGroupFriendsSearchInput', function (e) {
    var searctext = $(this).val();
    if (searctext) {
        $('.create-group-friends').hide();
        $('.create-group-friend-name').each(function () {
            if ($(this).text().toUpperCase().indexOf(searctext.toUpperCase()) != -1) {
                $('#createGroupFriend' + $(this).attr('friend-id')).show()
            }
        })
    } else {
        $('.create-group-friends').show();
    }
});


function submitCreateGroup() {
    let group_name = $('#GroupName').val();
    group_name = group_name.trim();
    if (!group_name) {
        return false;
    }
    let group_members = [];
    $("input:checkbox[class=GroupFirend]:checked").each(function () {
        group_members.push($(this).val());
    });
    if (group_members.length < 1) {
        return false;
    }

    /* CurrentRoomData['image']  */
    const params = {
        roomName: group_name,
        roomOwnerId: loginUserData.chat_user_id,
        roomMembers: group_members,
        group_image: CurrentRoomData['image']
    };
    socket.emit("createGroup", params);
    $('#CreareGroupModal').modal('hide')
}


function showCreateBroadcastModal() {

    let AuthToken = localStorage.getItem("AuthToken")

    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");
    myHeaders.append("Authorization", "Bearer " + AuthToken);

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(phpServerUrl + "user/followers/chat-users?search_srting=&page=", requestOptions)
        .then(result => result.text())
        .then((response) => {
            response = JSON.parse(response)
            if (response.status == true) {
                $('#CreareBroadcastListSection').empty();
                let friends = response.data;
                friends.forEach(element => {
                    const html = `
                    <div class="chat broadcast-friends" id="createBroadcastFriend`+ element._id + `">
                        <div class="chat-left">
                            <img src="`+ element.image + `" />
                        </div>
                        <div class="chat-right">
                            <div class="chat-right-top">
                                <span class="contact-name broadcast-friend-name" friend-id="`+ element._id + `">` + element.name + `</span>
                            </div>
                            <div class="chat-right-bottom">
                                <div class="chat-right-bottom-left">
    
                                </div>
                                <div class="chat-right-bottom-right">
                                    <input type="checkbox" class="BroadcastFirend" value="`+ element._id + `" broadcast-friend-name="` + element.name + `" />
                                </div>
                            </div>
                        </div>
                    </div>`;
                    $('#CreareBroadcastListSection').append(html)
                });
                $('#CreareBroadcastModal').modal('show')
            }
        })
        .catch(error => console.log('error', error));
}

$(document).on('change', '.BroadcastFirend', function (e) {
    let broadcastMemberNames = [];
    var counter = 0;
    $("input:checkbox[class=BroadcastFirend]:checked").each(function () {
        broadcastMemberNames.push($(this).attr('broadcast-friend-name'));
        counter++
    });
    let BroadcastName = "";
    if (broadcastMemberNames.length > 2) {
        for (let index = 0; index < 2; index++) {
            BroadcastName = BroadcastName + broadcastMemberNames[index];
        }
        BroadcastName = BroadcastName + ".....";
    } else {
        for (let index = 0; index < broadcastMemberNames.length; index++) {
            BroadcastName = BroadcastName + broadcastMemberNames[index];
        }
    }
    $('#BroadcastName').val(BroadcastName)
});


function submitCreateBroadcast() {
    let broadcast_name = $('#BroadcastName').val();
    broadcast_name = broadcast_name.trim();
    if (!broadcast_name) {
        return false;
    }
    let broadcast_members = [];
    $("input:checkbox[class=BroadcastFirend]:checked").each(function () {
        broadcast_members.push($(this).val());
    });
    if (broadcast_members.length < 1) {
        return false;
    }

    const params = {
        roomName: broadcast_name,
        roomOwnerId: loginUserData.chat_user_id,
        roomMembers: broadcast_members,
        group_image: "https://wokii.io/backend/public/images/radio-broadcast.png"
    };
    //socket.emit("createGroup", params);
    $('#CreareBroadcastModal').modal('hide')
}

$(document).on('keyup', '#creareBroadcastFriendsSearchInput', function (e) {
    var searctext = $(this).val();
    if (searctext) {
        $('.broadcast-friends').hide();
        $('.broadcast-friend-name').each(function () {
            if ($(this).text().toUpperCase().indexOf(searctext.toUpperCase()) != -1) {
                $('#createBroadcastFriend' + $(this).attr('friend-id')).show()
            }
        })
    } else {
        $('.broadcast-friends').show();
    }
});

$(document).on('keypress', '#messageTextInput', function (event) {
    if (currentRoomId) {
        socket.emit("typing", { roomId: currentRoomId, userId: loginUserData.chat_user_id, name: loginUserData.display_name });
    }

    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode === 13 && !event.shiftKey) {
        var message = $(this).val();
        message = message.trim();
        if (message && message != '') {
            let roomMembers = [];
            if (currenFriendId) {
                roomMembers = [currenFriendId];
            }
            roomType = "single";
            if (CurrentRoomData.roomType) {
                roomType = CurrentRoomData.roomType;
            }
            message = message.replace(/<script[^>]*>/gi, "&lt;script&rt;").replace(/<\/script[^>]*>/gi, "&lt;/script&rt;");
            const params = {
                userName: loginUserData.display_name,
                userImage: loginUserData.image,
                roomId: currentRoomId,
                roomName: CurrentRoomData.name,
                roomImage: CurrentRoomData.image,
                roomType: roomType,
                roomOwnerId: loginUserData.chat_user_id,
                roomMembers: roomMembers,
                parent_message_id: replyMessageId,
                message: message,
                message_type: "text",
                attachment: []
            };
            replyMessageId = "";
            removeReply();
            socket.emit("sendmessage", params);
            $(this).val('');
        }
    }

});

function showSelcctFileTypeModal() {
    $('#SelcctFileTypeModal').modal('show')
}

message_type = "document";
function selectFile(type) {
    $("#messageFileInput").removeAttr("accept");
    message_type = type;
    if (type == "image") {
        $("#messageFileInput").attr("accept", "image/png, image/gif, image/jpeg");
    }
    if (type == "video") {
        $("#messageFileInput").attr("accept", "video/mp4,video/x-m4v,video/*");
    }
    if (type == "audio") {
        $("#messageFileInput").attr("accept", "audio/mp3,audio/*;capture=microphone");
    }

    if (message_type == "location") {
        //$('#SelcctFileTypeModal').modal('hide')
        $('#SelectLocationModal').modal('show')
    } else {
        $('#messageFileInput').trigger('click');
    }
}

$(document).on('change', ".messageFileInput", async function () {
    $('#SelcctFileTypeModal').modal('hide')
    let files = $('#messageFileInput')[0].files
    if (files) {

        const messageFiles = [];

        var bucket = new AWS.S3({
            accessKeyId: "AKIAZPM2DFBY7BENGCGG",
            secretAccessKey: "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",
            region: 'ap-south-1'
        });

        for (let index = 0; index < files.length; index++) {

            /* file = files[index];
            folderName = "Document/";
            fileName = 'SampleFile';

            const params = {
                Bucket: "testing-ebiz",
                Key: folderName + fileName,
                Body: file,
                ContentType: file.type
            };

            bucket.upload(params, function (err, data) {

                if (err) {
                    console.log('There was an error uploading your file: ', err);
                    return false;
                }
                console.log('Successfully uploaded file.', data);
                return true;
            }); */
            var form = new FormData();
            form.append("chat_file", files[index]);
            var settings = {
                "url": socketUrl + "/api/chat/upload/",
                "method": "POST",
                "timeout": 0,
                "processData": false,
                "mimeType": "multipart/form-data",
                "contentType": false,
                "data": form
            };

            await $.ajax(settings).done(function (response) {
                response = JSON.parse(response)
                messageFiles.push(response.file_url)

            });
        }

        //return 0;
        roomType = "single";
        if (CurrentRoomData.roomType) {
            roomType = CurrentRoomData.roomType;
        }
        let roomMembers = [];
        if (currenFriendId) {
            roomMembers = [currenFriendId];
        }
        const params = {
            userName: loginUserData.display_name,
            userImage: loginUserData.image,
            roomId: currentRoomId,
            roomName: CurrentRoomData.name,
            roomImage: CurrentRoomData.image,
            roomType: roomType,
            roomOwnerId: loginUserData.chat_user_id,
            roomMembers: roomMembers,
            message: "",
            message_type: message_type,
            attachment: messageFiles
        };
        removeReply();
        socket.emit("sendmessage", params);
    }
});


let CurrentRoomMembers = [];
function ShowRoonDetailes() {
    if (CurrentRoomData.roomType != "single") {
        var settings = {
            "url": socketUrl + "/api/group/get-group-details?roomId=" + CurrentRoomData._id,
            "method": "GET",
            "timeout": 0,
        };
        $.ajax(settings).done(function (response) {
            response = response.data;
            var displayNone = "display: none;";
            var readonly = "readonly";
            if (response.owner == loginUserData.chat_user_id) {
                displayNone = "";
                readonly = "";
            }


            let group_members = response.group_members;
            let infoHtml = `
            <div class="row">
                <div class="col-md-12 p-2">
                    <input type="text" class="form-control" id="UpdateGroupName" placeholder="Group Name" value="`+ response.group_name + `"
                        style="font-size: 2rem" `+ readonly + `>
                </div>
                <div class="col-md-6 p-2">
                    <input type="file" class="form-control mi-1 GroupIImage" id="GroupIImage"
                        action-type="updateGroup" style="font-size: 2rem ; `+ displayNone + `">
                </div>
                <div class="col-md-6 p-2 text-end">
                    <img src="`+ response.group_image + `" alt=""
                        style="width: 100px; height:100px;" id="updateGroupImage">
                </div>
                <div class="col-md-6 p-2 group-details-actions">
                    <button type="button" class="btn btn-primary" style="font-size: 2rem; `+ displayNone + `" onclick="UpdateGroup();">Update Group
                    </button>
                    
                </div>
                <div class="col-md-6 p-2 text-end group-details-actions">
                    <button type="button" class="btn btn-primary" style="font-size: 2rem;`+ displayNone + `" onclick="ShowAddGroupMembermodal();">Add Group Members
                    </button>
                </div>
            </div>`;
            $('#GroupDetailesInFoFormSection').html(infoHtml);

            if (group_members) {
                $('#GroupDetailesMemberList').empty();

                for (const member of group_members) {
                    let element = member.user;
                    if (!element) {
                        continue
                    }
                    CurrentRoomMembers.push(element._id)
                    let member_name = element.name;
                    let member_remove_button = "block";
                    if (element._id == loginUserData.chat_user_id) {
                        member_name = "You";
                    }
                    if (response.owner != loginUserData.chat_user_id || element._id == loginUserData.chat_user_id) {
                        member_remove_button = "none";
                    }
                    let memberhtml = `
                    <div class="chat group-members" id="GroupMember`+ element._id + `">
                        <div class="chat-left">
                            <img src="`+ element.image + `" />
                        </div>
                        <div class="chat-right">
                            <div class="chat-right-top">
                                <span class="contact-name group-member-name" group-member="`+ element._id + `">` + member_name + `</span>
                            </div>
                            <div class="chat-right-bottom">
                                <div class="chat-right-bottom-left">
                                </div>
                                <div class="chat-right-bottom-right group-details-actions"  style="display:`+ member_remove_button + `;">
                                    <button type="button" class="btn btn-outline-danger" onclick="AddAndRemoveGroupMember(['`+ element._id + `'],'REMOVE');">
                                        <img src="images/trash.svg" />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>`;
                    $('#GroupDetailesMemberList').append(memberhtml);
                }
            }
            $('#RoonDetailesModal').modal('show')
            setRoomUserPermissions(CurrentRoomData.isUserExitedFromGroup);
        });


    } else {
        return false;
    }
}


$(document).on('keyup', '#groupMembersSearchInput', function (e) {
    var searctext = $(this).val();
    if (searctext) {
        $('.group-members').hide();
        $('.group-member-name').each(function () {
            if ($(this).text().toUpperCase().indexOf(searctext.toUpperCase()) != -1) {
                $('#GroupMember' + $(this).attr('group-member')).show()
            }
        })
    } else {
        $('.group-members').show();
    }
});

async function AddAndRemoveGroupMember(members, operation) {

    var settings = {
        "url": socketUrl + "/api/group/update-member-to-group",
        "method": "POST",
        "timeout": 0,
        "headers": {
            "Content-Type": "application/json"
        },
        "data": JSON.stringify({
            "userId": loginUserData.chat_user_id,
            "roomId": currentRoomId,
            "members": members,
            "operation": operation
        }),
    };

    await $.ajax(settings).done(function (response) {

        if (operation == "ADD") {
            members.forEach(element => {
                CurrentRoomMembers.push(element)
                $('#NewGroupMember' + element).remove();
            });
        }
        if (operation == "REMOVE") {
            members.forEach(element => {
                var index = CurrentRoomMembers.indexOf(element);
                CurrentRoomMembers.splice(index, 1);
                $('#GroupMember' + element).remove();
            });
        }
    });
}


function ShowAddGroupMembermodal() {
    let AuthToken = localStorage.getItem("AuthToken")
    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");
    myHeaders.append("Authorization", "Bearer " + AuthToken);

    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(phpServerUrl + "user/followers/chat-users?search_srting=&page=", requestOptions)
        .then(result => result.text())
        .then((response) => {
            response = JSON.parse(response)
            if (response.status == true) {
                let friends = response.data;
                $('#NewGroupesMemberList').empty()
                friends.forEach(element => {
                    if (!CurrentRoomMembers.includes(element._id)) {
                        let nwMemberhtml = `
                        <div class="chat add-group-members" id="NewGroupMember`+ element._id + `">
                            <div class="chat-left">
                                <img src="`+ element.image + `" />
                            </div>
                            <div class="chat-right">
                                <div class="chat-right-top">
                                    <span class="contact-name add-group-member-name" add-group-member="`+ element._id + `">` + element.name + `</span>
                                </div>
                                <div class="chat-right-bottom">
                                    <div class="chat-right-bottom-left">
                                    </div>
                                    <div class="chat-right-bottom-right">
                                        <button type="button" class="btn btn-outline-success" onclick="AddAndRemoveGroupMember(['`+ element._id + `'],'ADD');">
                                            <img src="images/person-plus-fill.svg" />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>`;
                        $('#NewGroupesMemberList').append(nwMemberhtml)
                        $('#NewGroupesMemberModal').modal('show');
                    }
                });
            }
        })
        .catch(error => console.log('error', error));
}


$(document).on('keyup', '#addGroupesMemberSearchInput', function (e) {
    var searctext = $(this).val();
    if (searctext) {
        $('.add-group-members').hide();
        $('.add-group-member-name').each(function () {
            if ($(this).text().toUpperCase().indexOf(searctext.toUpperCase()) != -1) {
                $('#NewGroupMember' + $(this).attr('add-group-member')).show()
            }
        })
    } else {
        $('.add-group-members').show();
    }
});


$(document).on('change', '.GroupIImage', async function () {
    let files = $(this)[0].files;
    let action = $(this).attr('action-type');
    let uploadeImage = await uploadGroupImage(files);
    CurrentRoomData['image'] = uploadeImage;
    if (action == "updateGroup") {
        $('#updateGroupImage').attr('src', uploadeImage)
    } else {
        $('#newGeoupCreateImage').attr('src', uploadeImage)
    }

})

async function uploadGroupImage(files) {
    file_url = "";
    var form = new FormData();
    form.append("chat_file", files[0]);
    var settings = {
        "url": socketUrl + "/api/chat/upload/",
        "method": "POST",
        "timeout": 0,
        "processData": false,
        "mimeType": "multipart/form-data",
        "contentType": false,
        "data": form
    };
    await $.ajax(settings).done(function (response) {
        response = JSON.parse(response)
        file_url = response.file_url;
    });

    return file_url;
}

function UpdateGroup() {
    let group_name = $('#UpdateGroupName').val();
    group_name = group_name.trim()
    if (!group_name) {
        return false;
    }
    CurrentRoomData.name = group_name;
    var settings = {
        "url": socketUrl + "/api/group/update-group",
        "method": "PATCH",
        "timeout": 0,
        "headers": {
            "Content-Type": "application/json"
        },
        "data": JSON.stringify({
            "new_group_name": CurrentRoomData.name,
            "new_group_image": CurrentRoomData.image,
            "room_id": CurrentRoomData._id,
        }),
    };

    $.ajax(settings).done(function (response) {
        $("#RoonDetailesModal").modal('hide');
    })
}
let curretMessageSelected = "";
$(function () {
    var $contextMenu = $("#contextMenu");
    $("body").on("contextmenu", ".message-box", function (e) {
        $('.senderoptions').show();
        if ($(this).hasClass("receiver")) {
            $('.senderoptions').hide();
        }
        curretMessageSelected = $(this).attr('message-id')
        $contextMenu.css({
            display: "block",
            left: e.pageX,
            top: e.pageY
        });
        return false;
    });

    $('html').click(function () {
        $contextMenu.hide();
    });

    $("#contextMenu li a").click(function (e) {
        var f = $(this);

        if (f.text() == "Reply") {
            replyMessageId = curretMessageSelected;
            curretMessageSelected = "";
            $('#replyTextMessage').text($('#textMessage' + replyMessageId).text())
            $('#replyRowsection').show();
            $('#replyTextColSection').show();
        } else if (f.text() == "Delete For Me" || f.text() == "Delete For All") {
            let delete_type = f.text() == "Delete For Me" ? 'me' : 'all';
            const params = {
                userId: loginUserData.chat_user_id,
                messageId: curretMessageSelected,
                delete_type: delete_type
            }
            socket.emit("deleteMessage", params);
        } else if (f.text() == "Forward") {
            showForwardMessageModal();
        } else if (f.text() == "Info") {
            showMessageInfoModal(curretMessageSelected);
        }
    });
});

function showMessageInfoModal(curretMessageSelected) {

    var settings = {
        "url": socketUrl + "/api/chat/chat-info?message_id=" + curretMessageSelected,
        "method": "GET",
        "timeout": 0,
    };
    //
    $.ajax(settings).done(function (response) {
        response = response.data;
        if (response) {
            $('#MessageImfoMemberList').empty();
            response.forEach(element => {
                let member = currentgroupMembers.find(f => f._id == element.userId)

                let DeliveredCheckBox = "";
                let SeenCheckBox = "";
                if (element.status == "delivered") {
                    DeliveredCheckBox = `<img src="./images/check2-square.svg" />&nbsp&nbsp; ` + element.createdAt
                }

                if (element.status == "seen") {
                    DeliveredCheckBox = `<img src="./images/check2-square.svg" /> &nbsp&nbsp; ` + element.createdAt
                    SeenCheckBox = `<img src="./images/check2-square.svg" /> &nbsp&nbsp; ` + element.updatedAt
                }

                let nwGroupshtml = `
                <tr>
                    <td>
                    <img src="`+ member.image + `" style="width: 50px;height: 50px;border-radius: 50px;"/> &nbsp&nbsp;
                        `+ member.name + `
                    </td>
                    <td style="padding-top: 25px;">`+ DeliveredCheckBox + `</td>
                    <td style="padding-top: 25px;">`+ SeenCheckBox + `</td>
                </tr>`;
                $('#MessageImfoMemberList').append(nwGroupshtml)
            });

            $('#MessageImfoModal').modal('show')
        }

    });





    if (currentgroupMembers) {
        currentgroupMembers.forEach(element => {
            if (element._id != loginUserData.chat_user_id) {
                let nwGroupshtml = `
                <tr>
                    <td>
                    <img src="https://wokii.io/backend/public/images/user-avatar.png" style="width: 50px;height: 50px;"/>
                    </td>
                    <td style="padding-top: 25px;"><img src="./images/check2-square.svg" /></td>
                    <td style="padding-top: 25px;"><img src="./images/check2-square.svg" /></td>
                </tr>`;
                $('#MessageImfoMemberList').append(nwGroupshtml)
            }
        });
    }

    $('#MessageImfoModal').modal('show');
}

function showForwardMessageModal() {
    $('#ForwardMessageMemberList').empty()
    let AuthToken = localStorage.getItem("AuthToken")
    var settings = {
        "url": socketUrl + "/api/group/get-user-groups",
        "method": "GET",
        "timeout": 0,
        "headers": {
            "Content-Type": "application/json"
        },
        "data": {
            "userId": loginUserData.chat_user_id
        },
    };

    $.ajax(settings).done(function (response) {
        response = response.data;
        response.forEach(element => {
            let nwGroupshtml = `
            <div class="chat forward-message-members" id="ForwardMessageMember`+ element._id + `">
                <div class="chat-left">
                    <img src="`+ element.group_image + `" />
                </div>
                <div class="chat-right">
                    <div class="chat-right-top">
                        <span class="contact-name forward-message-member-name" forward-message-member="`+ element._id + `">` + element.group_name + `</span>
                    </div>
                    <div class="chat-right-bottom">
                        <div class="chat-right-bottom-left">
                        </div>
                        <div class="chat-right-bottom-right">
                                <input type="checkbox" class="ForwardMessageUser" value="`+ element._id + `" forward-type="room"> 
                        </div>
                    </div>
                </div>
            </div>`;
            $('#ForwardMessageMemberList').append(nwGroupshtml)
        });
    });

    var myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");
    myHeaders.append("Authorization", "Bearer " + AuthToken);


    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(phpServerUrl + "user/followers/chat-users?search_srting=&page=", requestOptions)
        .then(result => result.text())
        .then((response) => {
            response = JSON.parse(response)
            if (response.status == true) {
                let friends = response.data;
                friends.forEach(element => {
                    let nwMemberhtml = `
                    <div class="chat forward-message-members" id="ForwardMessageMember`+ element._id + `">
                        <div class="chat-left">
                            <img src="`+ element.image + `" />
                        </div>
                        <div class="chat-right">
                            <div class="chat-right-top">
                                <span class="contact-name forward-message-member-name" forward-message-member="`+ element._id + `">` + element.name + `</span>
                            </div>
                            <div class="chat-right-bottom">
                                <div class="chat-right-bottom-left">
                                </div>
                                <div class="chat-right-bottom-right">
                                        <input type="checkbox" class="ForwardMessageUser" value="`+ element._id + `" forward-type="user"> 
                                </div>
                            </div>
                        </div>
                    </div>`;
                    $('#ForwardMessageMemberList').append(nwMemberhtml)
                });
            }
        })
        .catch(error => console.log('error', error));
    $('#ForwardMessageMemberModal').modal('show');
}




$(document).on('keyup', '#forwardMessageMemberSearchInput', function (e) {
    var searctext = $(this).val();
    if (searctext) {
        $('.forward-message-members').hide();
        $('.forward-message-member-name').each(function () {
            if ($(this).text().toUpperCase().indexOf(searctext.toUpperCase()) != -1) {
                $('#ForwardMessageMember' + $(this).attr('forward-message-member')).show()
            }
        })
    } else {
        $('.forward-message-members').show();
    }
});

function removeReply() {
    $('.replySections').hide();
    $('#replyTextMessage').text('')
    replyMessageId = "";
}


function submitForwardMessage() {
    let members = [];
    $("input:checkbox[class=ForwardMessageUser]:checked").each(function () {
        var type = $(this).attr('forward-type')
        members.push({ type: type, id: $(this).val() })
    });
    var parms = {
        sender_id: loginUserData.chat_user_id,
        message_ids: [curretMessageSelected],
        forward_details: members,
    }
    $('#ForwardMessageMemberModal').modal('hide');
    socket.emit("forwardMessage", parms);
}


// *************************************************Sockit  **************************************************\\

let socket = io.connect(socketUrl);
socket.emit("join", { id: loginUserData.chat_user_id });

socket.on("getChatList", (chatUsers) => {
    console.log("getChatList ====> ", chatUsers);
    chatUsers = chatUsers.result;
    $('#RoomListSection').empty()
    chatUsers.forEach(element => {

        let chatRoom = {
            undeliveredMessageCount: element.undeliveredMessageCount,
            unseenMessageCount: element.unseenMessageCount,
            isUserExitedFromGroup: element.isUserExitedFromGroup,
            lastMessage: element.lastMessage,
            messageType: element.messageType,
            room_id: element.room._id,
            room_name: element.room.name,
            image_url: element.room.image,
            room_type: element.room.type,
            time: element.time

        }
        displayRoomList(chatRoom, "postappend")
    });
})


function displayRoomList(element, append) {

    var myDate = new Date(element.time);
    const chatTime = (myDate.getHours() < 10 ? '0' : '') + myDate.getHours() + ':' + (myDate.getMinutes() < 10 ? '0' : '') + myDate.getMinutes();
    var showlast = "none"
    var lastMessage = ""
    let lastMessageHTML = "";
    if (element.lastMessage) {

        showlast = "block";
        lastMessage = element.lastMessage.message;
        if (element.undeliveredMessageCount > 0) {
            updateMessagestatus(element.lastMessage, 'delivered');
        }
        if (element.messageType == "text") {
            lastMessageHTML = `
            <span class="chat-message" id="chatLastMessage`+ element.room_id + `" > ` + element.lastMessage.message + `</span>
            `;
        } else if (element.messageType == "document") {
            lastMessageHTML = `
            <img class="image-icon" src="images/file-earmark-arrow-down.svg" />
            <span class="chat-message">Document</span>`;
        } else if (element.messageType == "image") {
            lastMessageHTML = `
            <img class="image-icon" src="images/camera-icon.svg" />
            <span class="chat-message">Image</span>`;
        }
        else if (element.messageType == "video") {
            lastMessageHTML = `
            <img class="image-icon" src="images/file-play.svg" />
            <span class="chat-message">Video</span>`;
        }
        else if (element.messageType == "audio") {
            lastMessageHTML = `
            <img class="image-icon" src="images/file-music.svg" />
            <span class="chat-message">Audio</span>`;
        }
        else if (element.messageType == "contact") {
            lastMessageHTML = `
            <img class="image-icon" src="images/person-lines-fill.svg" />
            <span class="chat-message">Contact</span>`;
        }
        else if (element.messageType == "location") {
            lastMessageHTML = `
            <img class="image-icon" src="images/geo-alt.svg" />
            <span class="chat-message">Location</span>`;
        }


    }

    let dropdownHTML = `<a href="javascript:void(0);" class="dropdown-item" onclick="removeAllChat('` + element.room_id + `','` + element.room_type + `');">Delete Chat</a>`;
    if (element.room_type == "multiple" && element.isUserExitedFromGroup == false) {
        dropdownHTML = dropdownHTML + `<a href="javascript:void(0);" class="dropdown-item" onclick="exitGroup('` + element.room_id + `','` + element.room_type + `');" id="exitGroupButton` + element.room_id + `">Exit Group</a>`
    }
    let unreadMessagesCss = `style="display: none"`;
    if (element.unseenMessageCount > 0) {
        unreadMessagesCss = ``;
    }



    let html = `
        <div class="chat chat-rooms" id="ChatRoom` + element.room_id + `">
            <div class="chat-left" onclick="getMessageHistory('`+ element.room_id + `' , '` + element.room_name + `','` + element.image_url + `' ,'` + element.room_type + `',` + element.isUserExitedFromGroup + `);">
                <img src="`+ element.image_url + `" />
            </div>
            <div class="chat-right">
                <div class="chat-right-top" onclick="getMessageHistory('`+ element.room_id + `' , '` + element.room_name + `','` + element.image_url + `' ,'` + element.room_type + `',` + element.isUserExitedFromGroup + `);">
                    <span class="contact-name chat-room-name"  room-id="`+ element.room_id + `">` + element.room_name + `</span>
                    <span class="chat-date">`+ chatTime + `</span>
                </div>
                <div class="chat-right-bottom">
                    <div class="chat-right-bottom-left room-last-message-section" id="lastMessageSection`+ element.room_id + `">
                        `+ lastMessageHTML + `
                    </div>
                    <div class="chat-right-bottom-left room-menber-typing-status-section" id="typingStatusSection`+ element.room_id + `">
                    </div>
                    <div class="chat-right-bottom-right" >
                        <span class="unread-messages-number"  id="unreadMessages`+ element.room_id + `"  ` + unreadMessagesCss + `> ` + element.unseenMessageCount + ` </span>
                        <div class="dropdown">
                                <a href="#" class="chat-options dropdown-toggle" data-bs-toggle="dropdown">
                                <img src="./images/down-arrow.svg"/>
                                </a>
                            <div class="dropdown-menu">
                                `+ dropdownHTML + `
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        `;

    if (append == "postappend") {
        $('#RoomListSection').append(html)
    } else {
        $('#RoomListSection').prepend(html)
    }
}
$(document).on('keyup', '#chatRoomSearchInput', function (e) {
    var searctext = $(this).val();
    if (searctext) {
        $('.chat-rooms').hide();
        $('.chat-room-name').each(function () {
            if ($(this).text().toUpperCase().indexOf(searctext.toUpperCase()) != -1) {
                $('#ChatRoom' + $(this).attr('room-id')).show()
            }
        })
    } else {
        $('.chat-rooms').show();
    }
});

socket.on("findRoom", (roomData) => {
    let room = roomData.room;
    if (!isEmpty(room)) {
        CurrentRoomData = {
            _id: room._id,
            name: room.name,
            image: room.image,
            roomType: room.type,
            isUserExitedFromGroup: false

        };
        currentRoomId = room._id;
        $("#unreadMessages" + currentRoomId).text(0)
        $("#unreadMessages" + currentRoomId).hide();
        $('#mainChatSection').show();
        $('#currentRoomMessagesection').empty();
        socket.emit("getChatHistory", { roomId: currentRoomId, userId: loginUserData.chat_user_id })
        displayCurrentRoomInfo(CurrentRoomData);
    }

})

socket.on("typing", (typingData) => {
    if ((currentRoomId == typingData.result.roomId) && (typingData.result.userId != loginUserData.chat_user_id)) {
        $('.typing-status').text(typingData.result.name + " is typing...");
        $('.typing-status').show();

        $('#lastMessageSection' + typingData.result.roomId).hide();
        $('#typingStatusSection' + typingData.result.roomId).text(typingData.result.name + " is typing...");
        $('#typingStatusSection' + typingData.result.roomId).show();
    } else {
        if (typingData.result.userId != loginUserData.chat_user_id) {
            $('#lastMessageSection' + typingData.result.roomId).hide();
            $('#typingStatusSection' + typingData.result.roomId).text(typingData.result.name + " is typing...");
            $('#typingStatusSection' + typingData.result.roomId).show();
        }
    }

})

setInterval(() => {
    $('.typing-status').hide();
    $('.room-menber-typing-status-section').hide();
    $('.room-last-message-section').show();
}, 5000);

socket.on("newGroupCreated", (groupResived) => {
    roomData = groupResived.result;
    let room = {
        image_url: roomData.roomImage,
        lastMessage: null,
        room_id: roomData.roomId,
        room_name: roomData.roomName,
        room_type: roomData.roomType,
        time: roomData.time,
        isUserExitedFromGroup: false
    }
    displayRoomList(room, 'prepend')
    if (roomData.fromUser == loginUserData.chat_user_id) {
        CurrentRoomData = {
            _id: roomData.roomId,
            name: roomData.roomName,
            image: roomData.roomImage,
            roomType: roomData.roomType,
            isUserExitedFromGroup: false
        };
        currentRoomId = roomData.roomId;
        socket.emit("joinRoom", { roomId: currentRoomId, userId: loginUserData.chat_user_id });
        const params = {
            userName: loginUserData.display_name,
            userImage: loginUserData.image,
            roomId: currentRoomId,
            roomName: CurrentRoomData.name,
            roomImage: CurrentRoomData.image,
            roomType: roomData.roomType,
            roomOwnerId: loginUserData.chat_user_id,
            roomMembers: [],
            parent_message_id: replyMessageId,
            message: loginUserData.display_name + " is created new group " + roomData.roomName,
            message_type: "notify",
            attachment: []
        };
        socket.emit("sendmessage", params);
        $('#mainChatSection').show();
        $('#currentRoomMessagesection').empty();
        setRoomUserPermissions();
        displayCurrentRoomInfo(CurrentRoomData);
    }
})



function removeAllChat(room_id, room_type) {

    var settings = {
        "url": socketUrl + "/api/chat/delete-all-chat",
        "method": "DELETE",
        "timeout": 0,
        "headers": {
            "Content-Type": "application/json"
        },
        "data": JSON.stringify({
            "userId": loginUserData.chat_user_id,
            "roomId": room_id
        }),
    };

    $.ajax(settings).done(function (response) {
        $('#ChatRoom' + room_id).remove();
        if (CurrentRoomData._id == room_id) {
            $('#currentRoomMessagesection').empty();
            $('#mainChatSection').hide();
        }
    });
}

function exitGroup(room_id, room_type) {

    var settings = {
        "url": socketUrl + "/api/group/exit-from-group",
        "method": "DELETE",
        "timeout": 0,
        "headers": {
            "Content-Type": "application/json"
        },
        "data": JSON.stringify({
            "userId": loginUserData.chat_user_id,
            "roomId": room_id
        }),
    };

    $.ajax(settings).done(function (response) {
        $('#exitGroupButton' + room_id).remove();
        socket.emit("disconnect");
        const params = {
            userName: loginUserData.display_name,
            userImage: loginUserData.image,
            roomId: currentRoomId,
            roomName: CurrentRoomData.name,
            roomImage: CurrentRoomData.image,
            roomType: CurrentRoomData.roomType,
            roomOwnerId: '',
            roomMembers: [],
            parent_message_id: '',
            message: loginUserData.display_name + " is left ",
            message_type: "notify",
            attachment: []
        };
        socket.emit("sendmessage", params);
    });
}

function getChatlist(LoginUserId) {
    socket.emit("getChatList", { userId: LoginUserId });
}


function setRoomUserPermissions(isUserExitedFromGroup = false) {
    if (isUserExitedFromGroup == true) {
        $('.type-message-bar').hide();
        $('.messageReplyBtn').hide();
        $('.messageDeleteForAllBtn').hide();
        $('.group-details-actions').hide();

    } else {
        $('.type-message-bar').show();
        $('.messageReplyBtn').show();
        $('.messageDeleteForAllBtn').show();
        //$('.group-details-actions').show();
    }

}
let checkOnlineStatussetInterval = "";
function checkOnlineStatus(friend) {
    if (checkOnlineStatussetInterval) {
        clearInterval(checkOnlineStatussetInterval);
    }
    let params = { to: friend, roomId: CurrentRoomData._id, fromUser: loginUserData.chat_user_id, status: "request" };
    socket.emit("checkOnlineStatus", params);
    checkOnlineStatussetInterval = setInterval(() => {
        socket.emit("checkOnlineStatus", params);
    }, 5000);

}

socket.on("checkOnlineStatus", (onlineStatus) => {
    if (onlineStatus.status == "request") {
        let params = { to: onlineStatus.fromUser, roomId: onlineStatus.roomId, fromUser: onlineStatus.to, status: "response" };
        socket.emit("checkOnlineStatus", params);
    } else {
        if (CurrentRoomData._id == onlineStatus.roomId) {
            $('.online-satus').show();
            hideonlineStatus();

        }
    }
})
let hideOnlineStatussetInterval = "";
function hideonlineStatus() {
    if (hideOnlineStatussetInterval) {
        clearInterval(hideOnlineStatussetInterval);
    }
    hideOnlineStatussetInterval = setInterval(() => {
        $('.online-satus').hide();
    }, 5000);
}



socket.on("getChatHistory", (ChatHistory) => {
    console.log("getChatHistory ====> ", ChatHistory);

    currentgroupMembers = []
    let messages = ChatHistory.result.chat;
    currentgroupMembers = ChatHistory.result.users;
    if (CurrentRoomData.roomType == 'single') {
        console.log("CurrentRoomData ====> ", CurrentRoomData);

        let friend = currentgroupMembers.find(f => f._id != loginUserData.chat_user_id)
        console.log("Me and  friend ====> ", loginUserData.chat_user_id, friend);
        checkOnlineStatus(friend._id);
    }


    if (messages && messages.length > 0) {
        $("#unreadMessages" + messages[0].roomId).text(0)
        $("#unreadMessages" + messages[0].roomId).hide();
        let lastMassage = messages.findLast((element) => element.from != loginUserData.chat_user_id);
        if (lastMassage) {
            updateMessagestatus(lastMassage, 'seen')
        }
    }
    messages.forEach(element => {
        displayMessage({
            _id: element._id,
            messageTime: element.createdAt,
            fromUser: element.from,
            message: element.message,
            roomId: element.roomId,
            messageType: element.message_type,
            attachment: element.attachment,
            parent_message: element.parent_message,
            isDeletedForAll: element.isDeletedForAll,
            deletedFor: element.deletedFor,
            seenBy: element.seenBy,
            isForwarded: element.isForwarded,
            status: element.status
        })
    });
})

socket.on("newMessageResive", (data) => {
    console.log("newMessageResive ====> ", data);
    data = data.result;
    data['status'] = "sent";
    let room = {
        _id: data.roomId,
        name: data.roomName,
        image: data.roomImage,
        roomType: data.roomType
    };

    let roomData = {
        isUserExitedFromGroup: false,
        image_url: data.roomImage,
        lastMessage: {
            message: data.message
        },
        messageType: data.messageType,
        room_id: data.roomId,
        room_name: data.roomName,
        room_type: data.roomType,
        time: data.messageTime
    }
    if (!currentRoomId && data.fromUser == loginUserData.chat_user_id) {
        CurrentRoomData = room;
        currentRoomId = room._id;
        socket.emit("joinRoom", { roomId: currentRoomId, userId: loginUserData.chat_user_id })
        displayMessage(data);
        $('#ChatRoom' + room._id).remove();
        displayRoomList(roomData, 'prepend')
    } else if (currentRoomId == room._id && data.fromUser == loginUserData.chat_user_id) {
        CurrentRoomData = room;
        currentRoomId = CurrentRoomData._id;
        $('#ChatRoom' + room._id).remove();
        displayRoomList(roomData, 'prepend')
        displayMessage(data);
    } else if (currentRoomId == room._id && data.fromUser != loginUserData.chat_user_id) {
        CurrentRoomData = room;
        currentRoomId = CurrentRoomData._id;
        $('#ChatRoom' + room._id).remove();
        displayRoomList(roomData, 'prepend')
        displayMessage(data);
        updateMessagestatus(data, 'seen')
    } else {
        updateMessagestatus(data, 'delivered')
        var existCount = parseInt($("#unreadMessages" + room._id).text());
        if (data.fromUser != loginUserData.chat_user_id) {
            existCount = existCount + 1;
        }
        $('#ChatRoom' + room._id).remove();
        displayRoomList(roomData, 'prepend')
        $("#unreadMessages" + room._id).text(existCount)
        if (existCount > 0) {
            $("#unreadMessages" + room._id).show();
        }
    }
})


function displayMessage(message) {

    var myDate = new Date(message.messageTime);
    const messageTime = (myDate.getHours() < 10 ? '0' : '') + myDate.getHours() + ':' + (myDate.getMinutes() < 10 ? '0' : '') + myDate.getMinutes();
    let messageHtml = '';
    let replyHtml = "";

    if (message.isDeletedForAll == true) {
        if (message.fromUser == loginUserData.chat_user_id) {
            messageHtml = `
            <div class="sender" message-id="`+ message._id + `" id="messageBox` + message._id + `">
                <span class="sender-message-tail">
                <img src="images/message-tail-sender.svg"></span>
                <span class="sender-message">This message was deleted.</span>
                <span class="message-time">`+ messageTime + `</span>
            </div>
            `;
        } else {
            messageHtml = `
            <div class="receiver" message-id="`+ message._id + `" id="messageBox` + message._id + `">
                <span class="receiver-message-tail">
                <img src="./images/message-tail-receiver.svg"></span>
                <span class="receiver-message">This message was deleted.</span>
                <span class="message-time">`+ messageTime + `</span>
            </div>
            `;
        }
        $('#currentRoomMessagesection').append(messageHtml);

        return true;
    }
    let forwardedHtml = "";
    if (message.isForwarded == true) {
        forwardedHtml = `<span class="sender-message reply-message"> <img src="./images/forward-fill.svg" style="width:25px;">Forwarded </span> <br/> `
    }


    if (message.parent_message != undefined && !isEmpty(message.parent_message)) {
        let parent_message = message.parent_message;
        if (parent_message.message_type == "text") {
            replyHtml = `<a href="#messageBox` + parent_message._id + `"><span class="sender-message reply-message"> ` + parent_message.message + ` </span></a> <br/>  `;
        } else {
            replyHtml = `<a href="#messageBox` + parent_message._id + `"><span class="sender-message reply-message"> <img src="./images/file-earmark.svg" style="width:25px;"></span></a> <br/> `
        }
    }

    let fromUserHtml = "";
    if (CurrentRoomData.roomType == "multiple") {

        let fromUser = currentgroupMembers.filter((member) => {
            if (member && member._id == message.fromUser) {
                return member
            }
        })
        let fromUsername = ""
        if (fromUser && message.messageType != "notify") {
            fromUser = fromUser[0]
            fromUsername = fromUser.name;
            if (fromUser._id == loginUserData.chat_user_id) {
                fromUsername = "You";
            }
        }
        fromUserHtml = `<span class="sender-message from-user-name"><b> ` + fromUsername + `</b> </span> <br/> `
    }

    let messageStatusHtml = "";
    if (message.fromUser == loginUserData.chat_user_id) {
        if (message.status == "sent") {
            messageStatusHtml = `<img class="message-status-` + message.status + `" src="./images/single-check.svg" id="messageStatus` + message._id + `">`;
        } else if (message.status == "delivered") {
            messageStatusHtml = `<img class="message-status-` + message.status + `" src="./images/double-check.svg" id="messageStatus` + message._id + `">`;
        } else if (message.status == "seen") {
            messageStatusHtml = `<img class="message-status-` + message.status + `" src="./images/double-check-seen.svg" id="messageStatus` + message._id + `">`;
        }

    }

    if (message.messageType == "text") {
        if (message.fromUser == loginUserData.chat_user_id) {
            messageHtml = `
            <div class="sender message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
            `+ fromUserHtml + `
                <span class="sender-message-tail"><img src="images/message-tail-sender.svg"></span>
                `+ replyHtml + ` ` + forwardedHtml + `
                <span class="sender-message" id="textMessage`+ message._id + `">` + message.message + `</span>
                <span class="message-time">`+ messageTime + `</span>
                <span class="message-status">
                    `+ messageStatusHtml + `
                </span>
            </div>
            `;
            $('#currentRoomMessagesection').append(messageHtml);
        } else if (message.fromUser != loginUserData.chat_user_id && CurrentRoomData._id == message.roomId) {
            messageHtml = `
            <div class="receiver message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
            `+ fromUserHtml + `
                <span class="receiver-message-tail"><img src="./images/message-tail-receiver.svg"></span>
                `+ replyHtml + `` + forwardedHtml + `
                <span class="receiver-message" id="textMessage`+ message._id + `">` + message.message + `</span>
                <span class="message-time">`+ messageTime + `</span>
            </div>
            `;
            $('#currentRoomMessagesection').append(messageHtml);
        }
    } else if (message.messageType == "image") {
        let row_col = "12";
        if (message.attachment.length > 1) {
            row_col = "6";
        }
        var loopCount = message.attachment.length;
        if (loopCount > 4) {
            loopCount = 4;
        }
        let attachment = message.attachment;
        let imageHtml = `<div class="row">`;
        for (let index = 0; index < loopCount; index++) {
            imageHtml = imageHtml + `<div class="col-md-` + row_col + ` p-2">`;
            imageHtml = imageHtml + `<img src="` + attachment[index] + `" alt=""style="max-height: 200px;
                max-width: 200px;border-radius:20px;">`;
            imageHtml = imageHtml + `</div>`;
        }
        imageHtml = imageHtml + "</div>";

        if (message.fromUser == loginUserData.chat_user_id) {
            messageHtml = `
            <div class="sender message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
            `+ fromUserHtml + `
                <span class="sender-message-tail"><img src="images/message-tail-sender.svg"></span>
                <span class="message-time">`+ messageTime + `</span>
                `+ replyHtml + `` + forwardedHtml + `
                `+ imageHtml + `
                <span class="message-status">
                    <img src="./images/double-check.svg" id="messageStatus`+ message._id + `">
                </span>
            </div>
            `;
            $('#currentRoomMessagesection').append(messageHtml);
        } else if (message.fromUser != loginUserData.chat_user_id && CurrentRoomData._id == message.roomId) {
            messageHtml = `
            <div class="receiver message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
            `+ fromUserHtml + `
                <span class="receiver-message-tail"><img src="./images/message-tail-receiver.svg"></span>
                <span class="message-time">`+ messageTime + `</span>
                `+ replyHtml + `` + forwardedHtml + `
                `+ imageHtml + `
            </div>
            `;
            $('#currentRoomMessagesection').append(messageHtml);
        }
    } else if (message.messageType == "video") {
        let attachment = message.attachment;
        let row_col = "12";
        if (message.attachment.length > 1) {
            row_col = "6";
        }
        var loopCount = message.attachment.length;
        if (loopCount > 4) {
            loopCount = 4;
        }

        let videoHtml = `<div class="row">`;
        for (let index = 0; index < loopCount; index++) {
            videoHtml = videoHtml + `<div class="col-md-` + row_col + ` p-2">`;
            videoHtml = videoHtml + `<video width="200" height="200" controls>
                        <source src="`+ attachment[index] + `" type="video/mp4">
                </video>`;
            videoHtml = videoHtml + `</div>`;
        }
        videoHtml = videoHtml + "</div>";

        if (message.fromUser == loginUserData.chat_user_id) {
            messageHtml = `
            <div class="sender message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
            `+ fromUserHtml + `
                <span class="sender-message-tail"><img src="images/message-tail-sender.svg"></span>
                <span class="message-time">`+ messageTime + `</span>
                `+ replyHtml + `` + forwardedHtml + `
                `+ videoHtml + `
                <span class="message-status">
                    <img src="./images/double-check.svg" id="messageStatus`+ message._id + `">
                </span>
            </div>
            `;
            $('#currentRoomMessagesection').append(messageHtml);
        } else if (message.fromUser != loginUserData.chat_user_id && CurrentRoomData._id == message.roomId) {
            messageHtml = `
            <div class="receiver message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
            `+ fromUserHtml + `
                <span class="receiver-message-tail">
                <img src="./images/message-tail-receiver.svg"></span>
                <span class="message-time">`+ messageTime + `</span>
                `+ replyHtml + `` + forwardedHtml + `
                `+ videoHtml + `
            </div>
            `;
            $('#currentRoomMessagesection').append(messageHtml);
        }
    } else if (message.messageType == "audio") {
        let attachment = message.attachment;
        let row_col = "12";
        if (message.attachment.length > 1) {
            row_col = "6";
        }
        var loopCount = message.attachment.length;
        if (loopCount > 4) {
            loopCount = 4;
        }

        let audioHtml = `<div class="row">`;
        for (let index = 0; index < loopCount; index++) {
            audioHtml = audioHtml + `<div class="col-md-` + row_col + ` p-2">`;
            audioHtml = audioHtml + `<audio controls>
            <source src="`+ attachment[index] + `" type="audio/ogg">
            <source src="`+ attachment[index] + `" type="audio/mpeg">
          </audio>`;
            audioHtml = audioHtml + `</div>`;
        }
        audioHtml = audioHtml + "</div>";

        if (message.fromUser == loginUserData.chat_user_id) {
            messageHtml = `
            <div class="sender message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
            `+ fromUserHtml + `
                <span class="sender-message-tail"><img src="images/message-tail-sender.svg"></span>
                <span class="message-time">`+ messageTime + `</span>
                `+ replyHtml + `` + forwardedHtml + `
                `+ audioHtml + `
                <span class="message-status">
                    <img src="./images/double-check.svg" id="messageStatus`+ message._id + `">
                </span>
            </div>
            `;
            $('#currentRoomMessagesection').append(messageHtml);
        } else if (message.fromUser != loginUserData.chat_user_id && CurrentRoomData._id == message.roomId) {
            messageHtml = `
            <div class="receiver message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
            `+ fromUserHtml + `
                <span class="receiver-message-tail"><img src="./images/message-tail-receiver.svg"></span>
                <span class="message-time">`+ messageTime + `</span>
                `+ replyHtml + `` + forwardedHtml + `
                `+ audioHtml + `
            </div>
            `;
            $('#currentRoomMessagesection').append(messageHtml);
        }
    }
    else if (message.messageType == "document") {
        let attachment = message.attachment;
        if (message.fromUser == loginUserData.chat_user_id) {
            for (let index = 0; index < attachment.length; index++) {
                messageHtml = `
                    <div class="sender message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
                    `+ fromUserHtml + `
                        <span class="sender-message-tail"><img src="images/message-tail-sender.svg"></span>
                        <span class="message-time">`+ messageTime + `</span> <br/>
                        `+ replyHtml + `` + forwardedHtml + `
                        <span class="sender-message"> 
                            <a href="`+ attachment[index] + `" download>
                                <img src="./images/file-earmark.svg" style="width: 200px;">
                            </a> 
                        </span>
                        <span class="message-status">
                            <img src="./images/double-check.svg" id="messageStatus`+ message._id + `">
                        </span>
                    </div>`;
                $('#currentRoomMessagesection').append(messageHtml);
            }
        } else if (message.fromUser != loginUserData.chat_user_id && CurrentRoomData._id == message.roomId) {
            for (let index = 0; index < attachment.length; index++) {
                messageHtml = `
                <div class="receiver message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
                `+ fromUserHtml + `
                    <span class="receiver-message-tail">
                    <img src="./images/message-tail-receiver.svg"></span>
                    <span class="message-time">`+ messageTime + `</span>  <br/>
                    `+ replyHtml + `` + forwardedHtml + `
                    <span class="sender-message"> 
                        <a href="`+ attachment[index] + `" download>
                            <img src="./images/file-earmark.svg" style="width: 200px;">
                        </a> 
                    </span>
                </div>`;
                $('#currentRoomMessagesection').append(messageHtml);
            }
        }
    } else if (message.messageType == "contact") {
        let attachment = message.attachment;
        if (message.fromUser == loginUserData.chat_user_id) {
            for (let index = 0; index < attachment.length; index++) {
                messageHtml = `
                    <div class="sender message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `" >
                    `+ fromUserHtml + `
                        <span class="sender-message-tail"><img src="images/message-tail-sender.svg"></span>
                        <span class="message-time">`+ messageTime + `</span> <br/>
                        `+ replyHtml + `` + forwardedHtml + `
                        <span class="sender-message"> 
                            <a href="`+ attachment[index] + `" download>
                                <img src="./images/person-lines-fill.svg" style="width: 200px;">
                            </a> 
                        </span>
                        <span class="message-status">
                            <img src="./images/double-check.svg" id="messageStatus`+ message._id + `">
                        </span>
                    </div>`;
                $('#currentRoomMessagesection').append(messageHtml);
            }
        } else if (message.fromUser != loginUserData.chat_user_id && CurrentRoomData._id == message.roomId) {
            for (let index = 0; index < attachment.length; index++) {
                messageHtml = `
                <div class="receiver message-box" message-id="`+ message._id + `" id="messageBox` + message._id + `">
                `+ fromUserHtml + `
                    <span class="receiver-message-tail">
                    <img src="./images/message-tail-receiver.svg"></span>
                    <span class="message-time">`+ messageTime + `</span>  <br/>
                    `+ replyHtml + `` + forwardedHtml + `
                    <span class="sender-message"> 
                        <a href="`+ attachment[index] + `" download>
                            <img src="./images/person-lines-fill.svg" style="width: 200px;">
                        </a> 
                    </span>
                    <span class="message-status">
                        <img src="./images/double-check.svg">
                    </span>
                </div>`;
                $('#currentRoomMessagesection').append(messageHtml);
            }
        }
    } else if (message.messageType == "notify") {
        messageHtml = `
        <div class="notify-message">
            <span class="sender-message notify-message-text">`+ message.message + `</span> <br>
            <span class="message-time">`+ messageTime + `</span>
        </div> `;
        $('#currentRoomMessagesection').append(messageHtml);
    }
    $('#currentRoomMessagesection').scrollTop($('#currentRoomMessagesection')[0].scrollHeight)
}

function updateMessagestatus(message, status) {

    if (status == "delivered") {
        socket.emit("markDelivered", { userId: loginUserData.chat_user_id, messageId: message._id });
    }
    if (status == "seen") {
        socket.emit("markSeen", { userId: loginUserData.chat_user_id, messageId: message._id });
    }
}



socket.on("deleteMessage", (deleteMessage) => {
    message = deleteMessage.result;

    if (message.isDeletedForAll == true) {
        let messagetime = $('#messageBox' + message._id).find('span.message-time').text();
        $('#messageBox' + message._id).empty();
        var deleteMessageHtml = "";
        if (message.from == loginUserData.chat_user_id) {
            deleteMessageHtml = `
            <span class="sender-message-tail">
            <img src="images/message-tail-sender.svg"></span>
            <span class="sender-message">This message was deleted.</span>
            <span class="message-time">`+ messagetime + `</span>
            `;
        } else {
            deleteMessageHtml = `
            <span class="receiver-message-tail">
            <img src="./images/message-tail-receiver.svg"></span>
            <span class="receiver-message">This message was deleted.</span>
            <span class="message-time">`+ messagetime + `</span>
            `;
        }
        $('#messageBox' + message._id).removeClass("message-box");
        $('#messageBox' + message._id).html(deleteMessageHtml)
    } else {
        if (message.deletedFor.includes(loginUserData.chat_user_id)) {
            $('#messageBox' + message._id).remove();
        }
    }
})

socket.on("markDelivered", (deliveredMessage) => {
    //markedmessagesCount
    let currentgroupMembersCount = currentgroupMembers.length - 1;
    if (currentgroupMembersCount == deliveredMessage.deliveredCount) {
        $('.message-status-sent').attr('src', "./images/double-check.svg");
        $(".message-status-sent").each(function (index) {
            $(this).removeClass("message-status-sent");
            $(this).addClass("message-status-delivered");
        });
    }
})

socket.on("markSeen", (seemMessage) => {
    //markedmessagesCount
    let currentgroupMembersCount = currentgroupMembers.length - 1;
    if (currentgroupMembersCount == seemMessage.seenCount) {
        $('.message-status-sent').attr('src', "./images/double-check-seen.svg");
        $('.message-status-delivered').attr('src', "./images/double-check-seen.svg");

        $(".message-status-sent").each(function (index) {
            $(this).removeClass("message-status-sent");
            $(this).addClass("message-status-seen");
        });

        $(".message-status-delivered").each(function (index) {
            $(this).removeClass("message-status-delivered");
            $(this).addClass("message-status-seen");
        });

    } else if ((seemMessage.seenCount < currentgroupMembersCount) && (currentgroupMembersCount == seemMessage.deliveredCount)) {
        $('.message-status-sent').attr('src', "./images/double-check.svg");
        $(".message-status-sent").each(function (index) {
            $(this).removeClass("message-status-sent");
            $(this).addClass("message-status-delivered");
        });
    }

})